#!/usr/bin/env python3
"""
Decrypt script bash obfuscated dan TIMPA file asli dengan hasil decrypt.

Pemakaian:
    python3 decrypt.py                      # proses semua file di folder ini (kecuali .py & .bak)
    python3 decrypt.py menu                 # proses semua file di folder 'menu'
    python3 decrypt.py menu --no-backup     # tanpa file .bak
    python3 decrypt.py menu --exclude .txt  # skip juga file .txt
    python3 decrypt.py menu sc2 sc3         # hanya file tertentu
"""

import os
import re
import shutil
import subprocess
import sys


def decrypt_content(content: str) -> str:
    new_lines = []
    for line in content.splitlines(keepends=True):
        stripped = line.lstrip()
        if stripped.startswith("eval "):
            idx = line.index("eval ")
            line = line[:idx] + "printf '%s\\n' " + line[idx + len("eval "):]
        new_lines.append(line)
    return "".join(new_lines)


def strip_ansi(text: str) -> str:
    return re.sub(r"\x1B\[[0-9;]*[mK]", "", text)


def is_obfuscated(path: str) -> bool:
    """Cek 'eval ' di seluruh file (bukan hanya 4 KB pertama)."""
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return "eval " in f.read()
    except OSError:
        return False


def decrypt_file(input_path: str, backup: bool = True) -> bool:
    if not os.path.isfile(input_path):
        print(f"[!] File tidak ditemukan: {input_path}\n")
        return False

    print(f"[*] Memproses: {input_path}")

    with open(input_path, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()

    if "eval " not in content:
        print(f"[!] Tidak ada 'eval ' di {input_path}, dilewati.\n")
        return False

    modified = decrypt_content(content)

    try:
        result = subprocess.run(
            ["bash", "-c", modified],
            capture_output=True,
            text=True,
            timeout=60,
        )
    except subprocess.TimeoutExpired:
        print(f"[!] Timeout saat memproses {input_path}\n")
        return False

    if result.returncode != 0 and not result.stdout:
        err = (result.stderr or "").strip()[:200]
        print(f"[!] Gagal: {err}\n")
        return False

    cleaned = strip_ansi(result.stdout)

    if backup:
        bak = input_path + ".bak"
        if not os.path.exists(bak):
            shutil.copy2(input_path, bak)
            print(f"    [bak] {bak}")

    with open(input_path, "w", encoding="utf-8") as f:
        f.write(cleaned)

    try:
        st = os.stat(input_path)
        os.chmod(input_path, st.st_mode | 0o111)
    except OSError:
        pass

    print(f"[✓] Ditimpa: {input_path}  ({len(cleaned)} bytes)\n")
    return True


def find_target_files(folder: str = ".", exclude_exts=(".py",)) -> list:
    files = []
    for name in sorted(os.listdir(folder)):
        path = os.path.join(folder, name)
        if not os.path.isfile(path):
            continue
        if name.endswith(".bak"):
            continue
        if any(name.endswith(ext) for ext in exclude_exts):
            continue
        if not is_obfuscated(path):
            continue
        files.append(path)
    return files


def main() -> None:
    args = sys.argv[1:]
    backup = True
    folder = "."
    explicit_files = []
    exclude_exts = [".py"]

    i = 0
    while i < len(args):
        a = args[i]
        if a == "--no-backup":
            backup = False
        elif a == "--exclude":
            i += 1
            if i >= len(args):
                print("[!] --exclude butuh argumen.")
                sys.exit(1)
            while i < len(args) and not args[i].startswith("--"):
                ext = args[i] if args[i].startswith(".") else "." + args[i]
                exclude_exts.append(ext)
                i += 1
            continue
        elif a in ("-h", "--help"):
            print(__doc__)
            sys.exit(0)
        elif os.path.isdir(a):
            folder = a
        else:
            explicit_files.append(a)
        i += 1

    if explicit_files:
        targets = []
        for f in explicit_files:
            p = f if os.path.isabs(f) else os.path.join(folder, f)
            targets.append(p)
    else:
        targets = find_target_files(folder, exclude_exts=tuple(exclude_exts))
        if not targets:
            print(f"[!] Tidak ada file obfuscated yang bisa diproses di folder '{folder}'.")
            sys.exit(1)
        print(f"[*] Ditemukan {len(targets)} file di '{folder}':")
        for t in targets:
            print(f"    - {t}")
        print()

    ok = 0
    for path in targets:
        if decrypt_file(path, backup=backup):
            ok += 1

    print(f"[✓] Total: {ok}/{len(targets)} file berhasil di-decrypt & ditimpa.")


if __name__ == "__main__":
    main()